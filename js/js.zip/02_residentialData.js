// 리스트 생성 관련
export const imgData = [
  {
    src: "../img/2020/APT_KUMHO_DAEWOO/kumho8.jpg",
    text: "광주 북구",
    info: "금호 대우 아파트",
    link: "https://www.google.co.https://example.com/link3/?hl=ko",
    customClass: "apartment",
  },
];
